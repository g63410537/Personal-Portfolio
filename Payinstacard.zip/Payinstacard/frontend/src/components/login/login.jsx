import React from "react";
import './login.css';
import { Link } from 'react-router-dom';
function Login() {
  return (
    <section className='login bg-G'>
      <div className='container'>
        <div className='row justify-content-center align-items-center'>
          <div className='col-md-5'>
            <div className='card login_card border-0'>
              <div className='card-body'>
                <h4 className='text-center'>Login to your account</h4>
                <p className='text-center'>Enter your credentials below.</p>
                <form className='mt-5 mb-4'>
                  <div className='row'>
                    <div className='col-12'>
                      <label className="form-label">User Name <span className='requred'>*</span></label>
                      <div className="input-group input-group-lg mb-3">
                        <input type="text" className="form-control" placeholder='User Name' />
                      </div>
                    </div>
                    <div className='col-12'>
                      <label className="form-label">Password <span className='requred'>*</span></label>
                      <div className="input-group input-group-lg mb-3">
                        <input type="password" className="form-control" placeholder='Password' />
                      </div>
                    </div>
                    <div className='col-12 mt-3'>
                      <button className='btn btn-01 w-100'>Sign in</button>
                    </div>
                  </div>
                </form>
                <p><Link to="/Forgot_Password" className='link'>Forgot Your Password?</Link></p>
                <p className='mb-0'>Haven’t an account? <Link to="/Sign_Up" className='link'>Sign up</Link>  here.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Login;
